#!/bin/bash

#===============================================================================
# Subdomain Takeover Tools Installation Script
#
# This script installs all required tools for subdomain enumeration and
# takeover detection.
#
# Supported OS: Ubuntu/Debian
#
# Tools installed:
# - Go (required for Go-based tools)
# - subfinder (subdomain enumeration)
# - httpx (HTTP probing)
# - subzy (takeover detection)
# - sublist3r (subdomain enumeration)
# - jq (JSON processing)
# - dig (DNS queries)
#
# Author: Manus AI
# Date: January 2026
#===============================================================================

set -e

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║     SUBDOMAIN TAKEOVER TOOLS - INSTALLATION SCRIPT           ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# Check if running as root
if [ "$EUID" -eq 0 ]; then
    echo -e "${YELLOW}[!] Running as root. Some tools will be installed globally.${NC}"
fi

# Update package lists
echo -e "${GREEN}[+]${NC} Updating package lists..."
sudo apt-get update -qq

# Install basic dependencies
echo -e "${GREEN}[+]${NC} Installing basic dependencies..."
sudo apt-get install -y -qq curl wget git jq dnsutils python3 python3-pip

#===============================================================================
# Install Go
#===============================================================================
echo -e "${GREEN}[+]${NC} Installing Go..."

GO_VERSION="1.21.6"
GO_TAR="go${GO_VERSION}.linux-amd64.tar.gz"

if ! command -v go &> /dev/null; then
    cd /tmp
    wget -q "https://go.dev/dl/${GO_TAR}"
    sudo rm -rf /usr/local/go
    sudo tar -C /usr/local -xzf "${GO_TAR}"
    rm "${GO_TAR}"
    
    # Add Go to PATH
    if ! grep -q "/usr/local/go/bin" ~/.bashrc; then
        echo 'export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin' >> ~/.bashrc
    fi
    export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin
    
    echo -e "    └── Go ${GO_VERSION} installed"
else
    echo -e "    └── Go already installed: $(go version)"
fi

# Ensure Go paths are set
export PATH=$PATH:/usr/local/go/bin:$HOME/go/bin
export GOPATH=$HOME/go

#===============================================================================
# Install Go-based tools
#===============================================================================

# Subfinder
echo -e "${GREEN}[+]${NC} Installing subfinder..."
if ! command -v subfinder &> /dev/null; then
    go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest 2>/dev/null
    echo -e "    └── subfinder installed"
else
    echo -e "    └── subfinder already installed"
fi

# httpx
echo -e "${GREEN}[+]${NC} Installing httpx..."
if ! command -v httpx &> /dev/null && [ ! -f "$HOME/go/bin/httpx" ]; then
    go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest 2>/dev/null
    echo -e "    └── httpx installed"
else
    echo -e "    └── httpx already installed"
fi

# subzy
echo -e "${GREEN}[+]${NC} Installing subzy..."
if ! command -v subzy &> /dev/null && [ ! -f "$HOME/go/bin/subzy" ]; then
    go install -v github.com/PentestPad/subzy@latest 2>/dev/null
    echo -e "    └── subzy installed"
else
    echo -e "    └── subzy already installed"
fi

#===============================================================================
# Install Python-based tools
#===============================================================================

# Sublist3r
echo -e "${GREEN}[+]${NC} Installing sublist3r..."
if ! command -v sublist3r &> /dev/null; then
    sudo pip3 install sublist3r 2>/dev/null
    echo -e "    └── sublist3r installed"
else
    echo -e "    └── sublist3r already installed"
fi

#===============================================================================
# Download fingerprints
#===============================================================================
echo -e "${GREEN}[+]${NC} Downloading latest fingerprints..."
FINGERPRINTS_DIR="$HOME/.config/subdomain-takeover"
mkdir -p "$FINGERPRINTS_DIR"
curl -s "https://raw.githubusercontent.com/EdOverflow/can-i-take-over-xyz/master/fingerprints.json" \
    -o "$FINGERPRINTS_DIR/fingerprints.json"
echo -e "    └── Fingerprints saved to $FINGERPRINTS_DIR/fingerprints.json"

#===============================================================================
# Verify installations
#===============================================================================
echo ""
echo -e "${BLUE}[VERIFICATION]${NC} Checking installed tools..."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

check_tool() {
    if command -v "$1" &> /dev/null || [ -f "$HOME/go/bin/$1" ]; then
        echo -e "${GREEN}✓${NC} $1"
        return 0
    else
        echo -e "${RED}✗${NC} $1 - NOT FOUND"
        return 1
    fi
}

check_tool "go"
check_tool "subfinder"
check_tool "httpx" || [ -f "$HOME/go/bin/httpx" ] && echo -e "${GREEN}✓${NC} httpx (in ~/go/bin)"
check_tool "subzy" || [ -f "$HOME/go/bin/subzy" ] && echo -e "${GREEN}✓${NC} subzy (in ~/go/bin)"
check_tool "sublist3r"
check_tool "jq"
check_tool "dig"

echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                 INSTALLATION COMPLETE                         ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "To use the tools, make sure to add Go binaries to your PATH:"
echo -e "${YELLOW}export PATH=\$PATH:/usr/local/go/bin:\$HOME/go/bin${NC}"
echo ""
echo -e "Or add this line to your ~/.bashrc and restart your terminal."
echo ""
