# End-to-End Guide to Subdomain Takeover

This document provides a comprehensive, step-by-step methodology for identifying and mitigating subdomain takeover vulnerabilities. The guide covers the entire process from subdomain enumeration to verification and remediation, incorporating best practices and a suite of powerful open-source tools.

## Introduction to Subdomain Takeover

A subdomain takeover occurs when a subdomain (e.g., `blog.example.com`) points to a third-party service (like GitHub Pages, Heroku, or an AWS S3 bucket) that is no longer in use or has been deleted. Because the DNS entry for the subdomain remains, an attacker can create an account on that third-party service and claim the abandoned subdomain, effectively taking control of it. This allows the attacker to host malicious content, conduct phishing campaigns, or steal user data, all while appearing as a legitimate part of the target domain.

This guide will walk you through the process of finding these vulnerable subdomains so your network team can fix them before they are exploited.

## Phase 1: Subdomain Enumeration

The first and most critical phase is to gather a comprehensive list of all subdomains for a given domain. We will use multiple sources to ensure maximum coverage.

### 1.1. Using crt.sh

Certificate Transparency (CT) logs are a valuable source of subdomain information. `crt.sh` provides a web interface and a JSON API to query these logs.

```bash
DOMAIN="example.com"
curl -s "https://crt.sh/?q=%25.${DOMAIN}&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > crtsh_subdomains.txt
```

This command queries `crt.sh` for all certificates associated with the domain, extracts the subdomain names, cleans up the output, and saves the unique subdomains to a file.

### 1.2. Using Subfinder

Subfinder is a fast and powerful passive subdomain enumeration tool that queries multiple online sources.

```bash
subfinder -d ${DOMAIN} -o subfinder_subdomains.txt
```

### 1.3. Using Sublist3r

Sublist3r is another popular OSINT tool that enumerates subdomains using search engines and other public sources.

```bash
sublist3r -d ${DOMAIN} -o sublist3r_subdomains.txt
```

### 1.4. Combining Results

To create a master list of unique subdomains, combine the outputs from all tools:

```bash
cat crtsh_subdomains.txt subfinder_subdomains.txt sublist3r_subdomains.txt | sort -u > all_subdomains.txt
```

## Phase 2: Probing for Live Subdomains

Now that we have a comprehensive list of subdomains, we need to identify which ones are live and check their HTTP status codes. `httpx` is the perfect tool for this.

```bash
cat all_subdomains.txt | httpx -silent -status-code -ip -o live_subdomains.txt
```

This command will take the list of subdomains, probe each one, and save the URL, status code, and IP address for live hosts to `live_subdomains.txt`.

## Phase 3: Identifying Potential Takeovers

With the list of live subdomains and their status codes, we can now hunt for potential takeover vulnerabilities.

### 3.1. Filtering for Interesting Status Codes

As you mentioned, `502 Bad Gateway` and `503 Service Unavailable` are interesting, but many other responses can indicate a potential takeover. We will focus on a broader range of responses in the next step. However, if you want to specifically look for these, you can use `grep`:

```bash
grep "\[502\]\|\[503\]" live_subdomains.txt
```

### 3.2. Automated Takeover Detection with Subzy

`subzy` is a tool that automatically checks for subdomain takeover vulnerabilities by matching the response body against a list of known vulnerable service fingerprints. We will use the `fingerprints.json` file we downloaded from the `can-i-take-over-xyz` repository.

```bash
subzy run --targets all_subdomains.txt --fingerprints fingerprints.json --output vulnerable_subdomains.txt
```

This command will test all the subdomains from our master list against the known fingerprints and save any potentially vulnerable domains to `vulnerable_subdomains.txt`.

## Phase 4: Manual Verification and Safe PoC

Automated tools are a great starting point, but manual verification is essential to confirm a vulnerability. For each domain in `vulnerable_subdomains.txt`:

1.  **Visit the URL in a browser:** The error message or page content will often give you a clue about the service it's pointing to.
2.  **Consult `can-i-take-over-xyz`:** The [can-i-take-over-xyz](https://github.com/EdOverflow/can-i-take-over-xyz) repository is the definitive guide. Search for the service or the fingerprint to find instructions on how to claim the subdomain.
3.  **Create a Safe Proof of Concept (PoC):** To demonstrate the vulnerability without causing harm, you can create a simple HTML file with a unique comment and host it on the claimed subdomain. For example:

    ```html
    <!-- PoC for subdomain takeover vulnerability by the security team -->
    ```

## Phase 5: Remediation

To fix a subdomain takeover vulnerability, your DNS team needs to **remove the dangling DNS record** for the affected subdomain from your DNS zone. It is also highly recommended to implement a regular audit process for your DNS records to prevent this from happening in the future.

## Automation Script

To streamline this entire process, you can use the following bash script:

```bash
#!/bin/bash

if [ -z "$1" ]; then
  echo "Usage: $0 <domain>"
  exit 1
fi

DOMAIN=$1

echo "[+] Starting subdomain enumeration for ${DOMAIN}..."

# Enumeration
curl -s "https://crt.sh/?q=%25.${DOMAIN}&output=json" | jq -r '.[].name_value' | sed 's/\*\.//g' | sort -u > crtsh_subdomains.txt
subfinder -d ${DOMAIN} -o subfinder_subdomains.txt -silent
sublist3r -d ${DOMAIN} -o sublist3r_subdomains.txt

cat crtsh_subdomains.txt subfinder_subdomains.txt sublist3r_subdomains.txt | sort -u > all_subdomains.txt

echo "[+] Probing for live subdomains..."

# Probing
cat all_subdomains.txt | httpx -silent -status-code -ip -o live_subdomains.txt

echo "[+] Identifying potential takeovers..."

# Takeover Detection
subzy run --targets all_subdomains.txt --fingerprints fingerprints.json --output vulnerable_subdomains.txt

echo "[+] Process complete. Check vulnerable_subdomains.txt for potential takeovers."
```

## References

1.  [OWASP Test for Subdomain Takeover (WSTG-CONF-10)](https://owasp.org/www-project-web-security-testing-guide/latest/4-Web_Application_Security_Testing/02-Configuration_and_Deployment_Management_Testing/10-Test_for_Subdomain_Takeover)
2.  [can-i-take-over-xyz GitHub Repository](https://github.com/EdOverflow/can-i-take-over-xyz)
