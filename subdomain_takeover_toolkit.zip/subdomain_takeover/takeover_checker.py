#!/usr/bin/env python3
"""
Subdomain Takeover Vulnerability Checker

This script checks a list of subdomains against known vulnerable service fingerprints
to identify potential subdomain takeover vulnerabilities.

Usage:
    python3 takeover_checker.py -i subdomains.txt -o results.json
    python3 takeover_checker.py -d example.com

Author: Manus AI
Date: January 2026
"""

import argparse
import json
import re
import sys
import concurrent.futures
from dataclasses import dataclass, asdict
from typing import List, Optional
import requests
from requests.exceptions import RequestException

# Disable SSL warnings for testing purposes
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Known vulnerable service fingerprints
# Source: https://github.com/EdOverflow/can-i-take-over-xyz
FINGERPRINTS = [
    {
        "service": "AWS/S3",
        "fingerprint": r"The specified bucket does not exist",
        "cname": ["s3.amazonaws.com"],
        "vulnerable": True
    },
    {
        "service": "AWS/Elastic Beanstalk",
        "fingerprint": r"NXDOMAIN",
        "cname": ["elasticbeanstalk.com"],
        "vulnerable": True
    },
    {
        "service": "GitHub Pages",
        "fingerprint": r"There isn't a GitHub Pages site here\.",
        "cname": ["github.io"],
        "vulnerable": True,
        "edge_case": True
    },
    {
        "service": "Heroku",
        "fingerprint": r"No such app",
        "cname": ["herokuapp.com", "herokussl.com"],
        "vulnerable": True,
        "edge_case": True
    },
    {
        "service": "Shopify",
        "fingerprint": r"Sorry, this shop is currently unavailable\.",
        "cname": ["myshopify.com"],
        "vulnerable": True,
        "edge_case": True
    },
    {
        "service": "Tumblr",
        "fingerprint": r"Whatever you were looking for doesn't currently exist at this address",
        "cname": ["tumblr.com"],
        "vulnerable": True,
        "edge_case": True
    },
    {
        "service": "Wordpress",
        "fingerprint": r"Do you want to register .*\.wordpress\.com\?",
        "cname": ["wordpress.com"],
        "vulnerable": True
    },
    {
        "service": "Ghost",
        "fingerprint": r"(Site unavailable|Failed to resolve DNS path for this host)",
        "cname": ["ghost.io"],
        "vulnerable": True
    },
    {
        "service": "Surge.sh",
        "fingerprint": r"project not found",
        "cname": ["surge.sh"],
        "vulnerable": True
    },
    {
        "service": "Bitbucket",
        "fingerprint": r"Repository not found",
        "cname": ["bitbucket.io"],
        "vulnerable": True
    },
    {
        "service": "Pantheon",
        "fingerprint": r"404 error unknown site!",
        "cname": ["pantheonsite.io"],
        "vulnerable": True
    },
    {
        "service": "Readme.io",
        "fingerprint": r"The creators of this project are still working on making everything perfect!",
        "cname": ["readme.io"],
        "vulnerable": True
    },
    {
        "service": "Zendesk",
        "fingerprint": r"Help Center Closed",
        "cname": ["zendesk.com"],
        "vulnerable": False
    },
    {
        "service": "Help Scout",
        "fingerprint": r"No settings were found for this company:",
        "cname": ["helpscoutdocs.com"],
        "vulnerable": True
    },
    {
        "service": "Help Juice",
        "fingerprint": r"We could not find what you're looking for\.",
        "cname": ["helpjuice.com"],
        "vulnerable": True
    },
    {
        "service": "Strikingly",
        "fingerprint": r"PAGE NOT FOUND",
        "cname": ["strikinglydns.com"],
        "vulnerable": True
    },
    {
        "service": "Uptimerobot",
        "fingerprint": r"page not found",
        "cname": ["stats.uptimerobot.com"],
        "vulnerable": True
    },
    {
        "service": "Pingdom",
        "fingerprint": r"Sorry, couldn't find the status page",
        "cname": ["pingdom.com"],
        "vulnerable": True
    },
    {
        "service": "Netlify",
        "fingerprint": r"Not Found - Request ID:",
        "cname": ["netlify.app", "netlify.com"],
        "vulnerable": True,
        "edge_case": True
    },
    {
        "service": "Vercel",
        "fingerprint": r"DEPLOYMENT_NOT_FOUND",
        "cname": ["vercel.app", "now.sh"],
        "vulnerable": True,
        "edge_case": True
    },
    {
        "service": "Microsoft Azure",
        "fingerprint": r"NXDOMAIN",
        "cname": ["cloudapp.net", "azurewebsites.net", "blob.core.windows.net", 
                  "cloudapp.azure.com", "azure-api.net", "azureedge.net"],
        "vulnerable": True
    },
    {
        "service": "Agile CRM",
        "fingerprint": r"Sorry, this page is no longer available\.",
        "cname": ["agilecrm.com"],
        "vulnerable": True
    },
    {
        "service": "Anima",
        "fingerprint": r"The page you were looking for does not exist\.",
        "cname": ["animaapp.io"],
        "vulnerable": True
    },
    {
        "service": "Campaign Monitor",
        "fingerprint": r"Trying to access your account\?",
        "cname": ["createsend.com"],
        "vulnerable": True
    },
    {
        "service": "Canny",
        "fingerprint": r"(Company Not Found|There is no such company)",
        "cname": ["canny.io"],
        "vulnerable": True
    },
    {
        "service": "Cargo Collective",
        "fingerprint": r"404 Not Found",
        "cname": ["cargocollective.com"],
        "vulnerable": True
    },
    {
        "service": "Fastly",
        "fingerprint": r"Fastly error: unknown domain:",
        "cname": ["fastly.net"],
        "vulnerable": False
    },
    {
        "service": "Fly.io",
        "fingerprint": r"404 Not Found",
        "cname": ["fly.dev"],
        "vulnerable": False
    },
    {
        "service": "Intercom",
        "fingerprint": r"Uh oh\. That page doesn't exist\.",
        "cname": ["intercom.io", "intercom.help"],
        "vulnerable": True,
        "edge_case": True
    },
    {
        "service": "JetBrains YouTrack",
        "fingerprint": r"is not a registered InCloud YouTrack",
        "cname": ["youtrack.cloud"],
        "vulnerable": True
    },
    {
        "service": "LaunchRock",
        "fingerprint": r"HTTP_STATUS=500",
        "cname": ["launchrock.com"],
        "vulnerable": True
    },
    {
        "service": "Ngrok",
        "fingerprint": r"Tunnel .*\.ngrok\.io not found",
        "cname": ["ngrok.io"],
        "vulnerable": True
    },
    {
        "service": "Short.io",
        "fingerprint": r"Link does not exist",
        "cname": ["short.io"],
        "vulnerable": True
    },
    {
        "service": "SmartJobBoard",
        "fingerprint": r"This job board website is either expired or its domain name is invalid\.",
        "cname": ["smartjobboard.com"],
        "vulnerable": True
    },
    {
        "service": "SurveySparrow",
        "fingerprint": r"Account not found\.",
        "cname": ["surveysparrow.com"],
        "vulnerable": True
    },
    {
        "service": "Uberflip",
        "fingerprint": r"The URL you've accessed does not provide a hub\.",
        "cname": ["read.uberflip.com"],
        "vulnerable": True
    },
    {
        "service": "Webflow",
        "fingerprint": r"The page you are looking for doesn't exist or has been moved\.",
        "cname": ["webflow.io"],
        "vulnerable": True,
        "edge_case": True
    },
    {
        "service": "Wix",
        "fingerprint": r"Looks Like This Domain Isn't Connected To A Website Yet!",
        "cname": ["wixsite.com"],
        "vulnerable": True,
        "edge_case": True
    },
    {
        "service": "Worksites",
        "fingerprint": r"Hello! Sorry, but the website you.*re looking for doesn.*t exist\.",
        "cname": ["worksites.net"],
        "vulnerable": True
    }
]


@dataclass
class TakeoverResult:
    """Represents the result of a takeover check for a single subdomain."""
    subdomain: str
    vulnerable: bool
    service: Optional[str] = None
    fingerprint_matched: Optional[str] = None
    edge_case: bool = False
    status_code: Optional[int] = None
    error: Optional[str] = None
    cname: Optional[str] = None


def check_subdomain(subdomain: str, timeout: int = 10) -> TakeoverResult:
    """
    Check a single subdomain for potential takeover vulnerabilities.
    
    Args:
        subdomain: The subdomain to check
        timeout: Request timeout in seconds
        
    Returns:
        TakeoverResult object with the findings
    """
    # Ensure subdomain has a protocol
    if not subdomain.startswith(('http://', 'https://')):
        url = f"https://{subdomain}"
    else:
        url = subdomain
        subdomain = subdomain.replace('https://', '').replace('http://', '')
    
    try:
        # Make the request
        response = requests.get(
            url,
            timeout=timeout,
            verify=False,
            allow_redirects=True,
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
        )
        
        content = response.text
        status_code = response.status_code
        
        # Check against all fingerprints
        for fp in FINGERPRINTS:
            if re.search(fp["fingerprint"], content, re.IGNORECASE):
                return TakeoverResult(
                    subdomain=subdomain,
                    vulnerable=fp.get("vulnerable", True),
                    service=fp["service"],
                    fingerprint_matched=fp["fingerprint"],
                    edge_case=fp.get("edge_case", False),
                    status_code=status_code
                )
        
        # No fingerprint matched
        return TakeoverResult(
            subdomain=subdomain,
            vulnerable=False,
            status_code=status_code
        )
        
    except requests.exceptions.ConnectionError as e:
        # Check if it's an NXDOMAIN (DNS resolution failure)
        error_str = str(e)
        if "Name or service not known" in error_str or "getaddrinfo failed" in error_str:
            # This could indicate a dangling DNS record
            return TakeoverResult(
                subdomain=subdomain,
                vulnerable=True,
                service="Potential Dangling DNS",
                fingerprint_matched="NXDOMAIN",
                error="DNS resolution failed - potential dangling record"
            )
        return TakeoverResult(
            subdomain=subdomain,
            vulnerable=False,
            error=f"Connection error: {str(e)[:100]}"
        )
    except requests.exceptions.Timeout:
        return TakeoverResult(
            subdomain=subdomain,
            vulnerable=False,
            error="Request timed out"
        )
    except RequestException as e:
        return TakeoverResult(
            subdomain=subdomain,
            vulnerable=False,
            error=f"Request error: {str(e)[:100]}"
        )


def check_subdomains(subdomains: List[str], threads: int = 10, timeout: int = 10) -> List[TakeoverResult]:
    """
    Check multiple subdomains for takeover vulnerabilities using thread pool.
    
    Args:
        subdomains: List of subdomains to check
        threads: Number of concurrent threads
        timeout: Request timeout in seconds
        
    Returns:
        List of TakeoverResult objects
    """
    results = []
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
        future_to_subdomain = {
            executor.submit(check_subdomain, subdomain, timeout): subdomain 
            for subdomain in subdomains
        }
        
        total = len(subdomains)
        completed = 0
        
        for future in concurrent.futures.as_completed(future_to_subdomain):
            completed += 1
            result = future.result()
            results.append(result)
            
            # Progress indicator
            status = "VULNERABLE" if result.vulnerable else "OK"
            color = "\033[91m" if result.vulnerable else "\033[92m"
            reset = "\033[0m"
            
            print(f"[{completed}/{total}] {color}{status}{reset} - {result.subdomain}", end="")
            if result.service:
                print(f" ({result.service})", end="")
            print()
    
    return results


def main():
    parser = argparse.ArgumentParser(
        description="Check subdomains for potential takeover vulnerabilities"
    )
    parser.add_argument(
        "-i", "--input",
        help="Input file containing list of subdomains (one per line)"
    )
    parser.add_argument(
        "-d", "--domain",
        help="Single domain to check"
    )
    parser.add_argument(
        "-o", "--output",
        default="takeover_results.json",
        help="Output JSON file for results (default: takeover_results.json)"
    )
    parser.add_argument(
        "-t", "--threads",
        type=int,
        default=10,
        help="Number of concurrent threads (default: 10)"
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="Request timeout in seconds (default: 10)"
    )
    parser.add_argument(
        "--vulnerable-only",
        action="store_true",
        help="Only output vulnerable subdomains"
    )
    
    args = parser.parse_args()
    
    # Get subdomains to check
    subdomains = []
    
    if args.input:
        try:
            with open(args.input, 'r') as f:
                subdomains = [line.strip() for line in f if line.strip()]
        except FileNotFoundError:
            print(f"Error: Input file '{args.input}' not found")
            sys.exit(1)
    elif args.domain:
        subdomains = [args.domain]
    else:
        print("Error: Please provide either -i (input file) or -d (domain)")
        parser.print_help()
        sys.exit(1)
    
    print(f"\n{'='*60}")
    print("SUBDOMAIN TAKEOVER VULNERABILITY CHECKER")
    print(f"{'='*60}")
    print(f"Checking {len(subdomains)} subdomain(s)")
    print(f"Threads: {args.threads}")
    print(f"Timeout: {args.timeout}s")
    print(f"{'='*60}\n")
    
    # Run the checks
    results = check_subdomains(subdomains, args.threads, args.timeout)
    
    # Filter results if requested
    if args.vulnerable_only:
        results = [r for r in results if r.vulnerable]
    
    # Convert to dict for JSON output
    results_dict = [asdict(r) for r in results]
    
    # Save results
    with open(args.output, 'w') as f:
        json.dump(results_dict, f, indent=2)
    
    # Print summary
    vulnerable_count = sum(1 for r in results if r.vulnerable)
    edge_case_count = sum(1 for r in results if r.edge_case)
    
    print(f"\n{'='*60}")
    print("SUMMARY")
    print(f"{'='*60}")
    print(f"Total checked: {len(subdomains)}")
    print(f"Vulnerable: {vulnerable_count}")
    print(f"Edge cases: {edge_case_count}")
    print(f"Results saved to: {args.output}")
    
    if vulnerable_count > 0:
        print(f"\n\033[91mWARNING: {vulnerable_count} potential takeover(s) found!\033[0m")
        print("\nVulnerable subdomains:")
        for r in results:
            if r.vulnerable:
                print(f"  - {r.subdomain} ({r.service or 'Unknown service'})")


if __name__ == "__main__":
    main()
